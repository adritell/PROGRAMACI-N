package ENTREGABLES;

import java.util.Scanner;

public class ej3 {
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        int entradas;
        int precioBase=8;
        int precioBaseImpar=8;
        float tarjeta= 10/100;
        String dia= " ";
        String siNo="";

        System.out.println("Venta de entradas CineCampa");
        System.out.println("Número de entradas: "); entradas= teclado.nextInt();
        teclado.nextLine();
        System.out.println("Día de la semana");
        dia= teclado.nextLine();
        System.out.println("¿Tiene la tarjeta CineCampa(s/n)?");
        siNo= teclado.nextLine();
        System.out.println("Aquí tiene sus entradas. Gracias por su compra.");

        if (!dia.equalsIgnoreCase("Miercoles") && !dia.equalsIgnoreCase("Jueves")){
            precioBase=8;
        }  if (dia.equalsIgnoreCase("Miercoles")){
            precioBase=5;
        } if (dia.equalsIgnoreCase("Jueves") && entradas%2==0){
            precioBase= 11;
        }  else if (dia.equalsIgnoreCase("Jueves") && entradas%2!=0){
            precioBase=11;


        }
        int total=entradas*precioBase;
        float descuento=total*tarjeta;
        System.out.println("Entradas individuales: "+entradas);
        System.out.println("Precio por entrada individual: "+precioBase);
        System.out.println("Total:"+ total);
        System.out.println("Descuento:" +descuento);
        System.out.println("A pagar: "+(total-descuento));

    }
}
