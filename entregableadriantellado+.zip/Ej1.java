package ENTREGABLES;

import java.util.Scanner;

public class Ej1 {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int altura,anchura;
        System.out.println("Introduce la altura de la figura:");
        altura= teclado.nextInt();
        System.out.println("Introduce la anchura:");
        anchura= teclado.nextInt();

        for (int i = 1; i < anchura; i++) {
            System.out.print("*");
            for (int j = 0; j < altura-1; j++) {
                System.out.print("*");
            }
            System.out.println();
            for (int k = 0; k < anchura; k++) {
                System.out.print("*");

            }
        }

    }
}
