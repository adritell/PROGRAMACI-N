package EXAMEN1;

public class Ej03 {
    public static void main(String[] args) {
        int numeroPalo = (int) (Math.random() * 4) + 1;
        String palos = "";
        String carta;

        if (numeroPalo == 1) {
            palos = "picas";
        } else if (numeroPalo == 2) {
            palos = "corazones";
        } else if (numeroPalo == 3) {
            palos = "diamantes";
        } else if (numeroPalo == 4) {
            palos = "tréboles";
        }

        int numeroCarta = (int) (Math.random() * 13) + 1;
        if (numeroCarta == 1) {
            carta = "As";
        } else if (numeroCarta == 11) {
            carta = "J";
        } else if (numeroCarta == 12) {
            carta = "Q";
        } else if (numeroCarta == 13) {
            carta = "K";
        } else {
            carta = String.valueOf(numeroCarta);
        }
        System.out.println(carta + " de " + palos);
    }
}
