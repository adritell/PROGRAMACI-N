package EXAMEN1;

import java.util.Scanner;

public class EJ01 {
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);

        int altura;
        System.out.println("Introduce la altura del árbol: ");
        altura= teclado.nextInt();
            while (true) {
                if (altura >= 4) {
                    for (int i = 0; i < altura; i++) {
                        System.out.println("*");
                        for (int j = 0; j < altura; j++) {
                            System.out.print("*");
                        }
                    }
                    break;
                }

                else {
                    System.out.println("Altura incorrecta, por favor vuelva a introducir la altura:");
                    altura= teclado.nextInt();
                }
            }

        }
}
