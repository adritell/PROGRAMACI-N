package EXAMEN1;

import java.util.Scanner;

public class EJ02 {
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        int num, invertir=0, resto;

        System.out.println("Introduzca el número que desee convertir a asteriscos: ");
        num= teclado.nextInt();

        while (num>0) {
            resto= num%10;
            invertir= invertir*10+resto;
            num=num/10;
        }
        System.out.println(invertir);
    }
}
