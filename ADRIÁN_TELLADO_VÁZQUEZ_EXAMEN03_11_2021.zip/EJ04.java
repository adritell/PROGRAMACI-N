package EXAMEN1;

import java.util.Scanner;

public class EJ04 {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        double cmsAltura, cmsAnchura,total;
        double envio= 3.25, escudo=2.50,escudo1=0;
        String escudoBor="";


        System.out.println("Introduzca la altura en cms:");
        cmsAltura= teclado.nextDouble();
        System.out.println("Ahora introduzca la anchura: ");
        cmsAnchura= teclado.nextDouble();
        teclado.nextLine();
        double cmsCuadrados= cmsAltura*cmsAnchura;
        double precioBase=0.01*cmsCuadrados;
        System.out.println("¿Quiere escudo bordado? (s/n): ");
        escudoBor=teclado.nextLine();

        System.out.println("Gracias. Aquí tiene el desglose de su compra.");

        System.out.println("Bandera de "+cmsCuadrados+"cm2="+ precioBase);
        System.out.println("Gastos de envío: "+envio);
        if (escudoBor.equalsIgnoreCase("s")) {
            System.out.println("Con escudo "+escudo);
            total=precioBase+envio+escudo;
            System.out.println("Total: "+ total);

        }else {
            System.out.println("Sin escudo: "+escudo1);
            total=precioBase+envio+escudo1;
            System.out.println("Total: "+ total);

        }

    }
}
